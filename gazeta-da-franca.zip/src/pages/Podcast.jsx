import React from "react";

const Podcast = () => {
  return (
    <div className="max-w-4xl mx-auto mt-8">
      <h1 className="text-2xl font-bold mb-4">Podcast</h1>
      <p>Conteúdo da página Podcast.</p>
    </div>
  );
};

export default Podcast;