import React from "react";

const Mundo = () => {
  return (
    <div className="max-w-4xl mx-auto mt-8">
      <h1 className="text-2xl font-bold mb-4">Mundo</h1>
      <p>Conteúdo da página Mundo.</p>
    </div>
  );
};

export default Mundo;